class InterfaceConformanceError(RuntimeError):
    pass
